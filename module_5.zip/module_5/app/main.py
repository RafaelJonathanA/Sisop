from fastapi import FastAPI, Body, Request # FastAPI utama
from fastapi.encoders import jsonable_encoder # JSON Handler
import pymongo # Menghubungkan ke Database MongoDB 
from pydantic import BaseModel # 
from bson.objectid import ObjectId # Identifikasi ID pada mongoDB
import uuid # Default ID Generator
import socket # Identifier tiap docker 
import time # Simulasi waktu request

MONGO_DETAILS = "mongodb://admin:admin@mongodb:27017/" # nama aplikasi docker mongodb
client = pymongo.MongoClient(MONGO_DETAILS)
db = client['test'] # nama databesnya 'tes'
collection = db['koleksi'] # nama collectionnya 'tes'

class Item(BaseModel):
    name: str
    age: int 
    rank: str

def myData(data):
    return {
        "id": str(data["_id"]),
        "name": data["name"],
        "age": data["age"],
        "rank": data["rank"],
    }

def myFullData(datas):
    return [myData(data) for data in datas]

    
def ResponseModel(data, message = "Success"):
    return {
        "data": [data],
        "code": 200,
        "message": message,
    }

def ErrorResponseModel(error, code, message):
    return {
        "error": error, 
        "code": code, 
        "message": message
    }

app = FastAPI()

@app.get('/')
async def home():
    return {
        "message": "This is server A",
        "hostname": socket.gethostname()}

@app.get('/fast')
async def hello():
    time.sleep(0.5)
    return {
        "message": "Hello world from server A",
        "opt": "fast"}

@app.get('/slow')
async def hello():
    time.sleep(1)
    return {
        "message": "Hello world from server A",
        "opt": "slow"}

@app.get("/all")
async def get_all_data():
    # print(client.tes.tes.find())
    # print(myFullData(client.tes.tes.find()))
    return ResponseModel(myFullData(collection.find()), "All Good")

# insert new data
@app.post("/create", response_model=Item)
async def create_data(request: Request, lister: Item = Body(..., embed=True)):
    lister = jsonable_encoder(lister)
    new_data = client.tes.tes.insert_one(lister)
    # return response with data inserted
    return lister

# get data by id
@app.get("/get/{id}")
async def get_data(id: str):
    Objinstance = ObjectId(id)
    data = collection.find_one({"_id": Objinstance})
    if data:
        return ResponseModel(myData(data), "A")
    else:
        return ErrorResponseModel("An error occurred.", 404, "Data doesn't exist.")